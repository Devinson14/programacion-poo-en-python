from Modelo_vehiculo import Vehiculo

class Camioneta(Vehiculo):
    def __init__(self, modelo, color, motor, tipo_combustible, capacidad_carga, tipo_traccion):
        super().__init__(modelo, color, motor, tipo_combustible)
        self.capacidad_carga = capacidad_carga
        self.tipo_traccion = tipo_traccion
    
    def mostrar_informacion_camioneta(self):
        info_base = self.mostrar_informacion()
        return (f"{info_base}, Capacidad de carga: {self.capacidad_carga} kg, "
                f"Tracción: {self.tipo_traccion}")
    
    def cargar_mercancia(self):
        return f"La camioneta {self.modelo} puede cargar hasta {self.capacidad_carga} kg."
    
    def sistema_traccion(self):
        return f"La camioneta tiene sistema de tracción {self.tipo_traccion}."
