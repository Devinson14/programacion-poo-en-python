class Vehiculo:
    def __init__(self, modelo, color, motor, tipo_combustible):
        self.modelo = modelo
        self.color = color
        self.motor = motor
        self.tipo_combustible = tipo_combustible
    
    def mostrar_informacion(self):
        return (f"Modelo: {self.modelo}, Color: {self.color}, "
                f"Motor: {self.motor}, Combustible: {self.tipo_combustible}")
    
    def arrancar(self):
        return f"El {self.modelo} está arrancando..."
    
    def apagar(self):
        return f"El {self.modelo} se ha apagado."