from Modelo_vehiculo import Vehiculo

class Auto(Vehiculo):
    def __init__(self, modelo, color, motor, tipo_combustible, num_puertas, capacidad_pasajeros):
        super().__init__(modelo, color, motor, tipo_combustible)
        self.num_puertas = num_puertas
        self.capacidad_pasajeros = capacidad_pasajeros
    
    def mostrar_informacion_auto(self):
        info_base = self.mostrar_informacion()
        return (f"{info_base}, Puertas: {self.num_puertas}, "
                f"Capacidad: {self.capacidad_pasajeros} pasajeros")
    
    def acelerar_frenar(self):
        return f"El auto {self.modelo} puede acelerar y frenar eficientemente."
    
    def sistema_direccion(self):
        return f"El auto {self.modelo} tiene dirección hidráulica."
    
    def climatizacion(self):
        return f"El auto {self.modelo} tiene aire acondicionado."