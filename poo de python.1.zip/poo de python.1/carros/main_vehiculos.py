from Modelo_auto import Auto
from Modelo_camioneta import Camioneta

def main_vehiculos():
    print("=" * 70)
    print("SISTEMA DE VEHÍCULOS")
    print("=" * 70)
    
   
    auto1 = Auto("BMW Z4", "Azul metálico", "3.0L 6 cilindros", "Gasolina", 2, 2)
    print("\n--- AUTO DEPORTIVO ---")
    print(auto1.mostrar_informacion_auto())
    print(auto1.arrancar())
    print(auto1.acelerar_frenar())
    print(auto1.sistema_direccion())
    print(auto1.climatizacion())
    print(auto1.apagar())
    
   
    camioneta1 = Camioneta("Ford F-150", "Blanco", "3.5L V6", "Gasolina", 1200, "4x4")
    print("\n--- CAMIONETA ---")
    print(camioneta1.mostrar_informacion_camioneta())
    print(camioneta1.arrancar())
    print(camioneta1.cargar_mercancia())
    print(camioneta1.sistema_traccion())
    print(camioneta1.apagar())

if __name__ == "__main__":
    main_vehiculos()