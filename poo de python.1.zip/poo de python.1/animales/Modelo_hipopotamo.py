from Modelo_animal import Animal

class Hipopotamo(Animal):
    def __init__(self, nombre, edad, habitat, dieta, peso, comportamiento):
        super().__init__(nombre, edad, habitat, dieta)
        self.peso = peso
        self.comportamiento = comportamiento
    
    def mostrar_informacion_hipopotamo(self):
        info_base = self.mostrar_informacion()
        return f"{info_base}, Peso: {self.peso} kg, Comportamiento: {self.comportamiento}"
    
    def reproducirse(self):
        return f"{self.nombre} se reproduce de forma vivípara en el agua."
    
    def moverse(self):
        return f"{self.nombre} se mueve nadando en el agua y caminando en tierra."
    
    def comunicarse(self):
        return f"{self.nombre} se comunica con gruñidos y rugidos."
    
    def descansar(self):
        return f"{self.nombre} descansa sumergido en el agua durante el día."
    
    def interaccion_social(self):
        return f"{self.nombre} es {self.comportamiento} y vive en grupos."

