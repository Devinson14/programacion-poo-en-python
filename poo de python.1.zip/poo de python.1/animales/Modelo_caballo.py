from Modelo_animal import Animal

class Caballo(Animal):
    def __init__(self, nombre, edad, habitat, dieta, tamano, color):
        super().__init__(nombre, edad, habitat, dieta)
        self.tamano = tamano
        self.color = color
    
    def mostrar_informacion_caballo(self):
        info_base = self.mostrar_informacion()
        return f"{info_base}, Tamaño: {self.tamano}, Color: {self.color}"
    
    def reproducirse(self):
        return f"{self.nombre} se reproduce de forma vivípara (da a luz crías vivas)."
    
    def comunicarse(self):
        return f"{self.nombre} se comunica relinchando."
    
    def moverse(self):
        return f"{self.nombre} se mueve galopando y corriendo."
    
    def adaptacion(self):
        return f"{self.nombre} está adaptado para correr largas distancias en {self.habitat}."

