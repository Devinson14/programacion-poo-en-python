class Animal:
    def __init__(self, nombre, edad, habitat, dieta):
        self.nombre = nombre
        self.edad = edad
        self.habitat = habitat
        self.dieta = dieta
    
    def mostrar_informacion(self):
        return (f"Nombre: {self.nombre}, Edad: {self.edad} años, "
                f"Hábitat: {self.habitat}, Dieta: {self.dieta}")
    
    def moverse(self):
        return f"{self.nombre} se está moviendo."
    
    def alimentarse(self):
        return f"{self.nombre} se está alimentando de {self.dieta}."
    
    def comunicarse(self):
        return f"{self.nombre} se está comunicando."


