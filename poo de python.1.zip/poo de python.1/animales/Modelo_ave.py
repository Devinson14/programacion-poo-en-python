from Modelo_animal import Animal

class Ave(Animal):
    def __init__(self, nombre, edad, habitat, dieta, tipo_plumaje, envergadura):
        super().__init__(nombre, edad, habitat, dieta)
        self.tipo_plumaje = tipo_plumaje
        self.envergadura = envergadura
    
    def mostrar_informacion_ave(self):
        info_base = self.mostrar_informacion()
        return (f"{info_base}, Plumaje: {self.tipo_plumaje}, "
                f"Envergadura: {self.envergadura} cm")
    
    def reproducirse(self):
        return f"{self.nombre} se reproduce por huevos (ovíparo)."
    
    def moverse(self):
        return f"{self.nombre} se mueve volando con una envergadura de {self.envergadura} cm."
    
    def comunicarse(self):
        return f"{self.nombre} se comunica cantando y emitiendo sonidos."
    
    def anidar(self):
        return f"{self.nombre} construye nidos para sus huevos."
    