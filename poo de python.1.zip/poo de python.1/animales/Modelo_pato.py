from Modelo_animal import Animal

class Pato(Animal):
    def __init__(self, nombre, edad, habitat, dieta, color_plumaje, tipo_pico):
        super().__init__(nombre, edad, habitat, dieta)
        self.color_plumaje = color_plumaje
        self.tipo_pico = tipo_pico
    
    def mostrar_informacion_pato(self):
        info_base = self.mostrar_informacion()
        return (f"{info_base}, Color del plumaje: {self.color_plumaje}, "
                f"Tipo de pico: {self.tipo_pico}")
    
    def reproducirse(self):
        return f"{self.nombre} se reproduce por huevos que pone cerca del agua."
    
    def moverse(self):
        return f"{self.nombre} puede nadar, caminar y volar."
    
    def comunicarse(self):
        return f"{self.nombre} se comunica graznando (cuac cuac)."
    
    def nadar(self):
        return f"{self.nombre} nada expertamente con sus patas palmeadas."
