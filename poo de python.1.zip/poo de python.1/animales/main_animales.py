from Modelo_caballo import Caballo
from Modelo_hipopotamo import Hipopotamo
from Modelo_ave import Ave
from Modelo_pato import Pato

def main_animales():
    print("=" * 70)
    print("SISTEMA DE ANIMALES")
    print("=" * 70)
    
   
    caballo1 = Caballo("Thunder", 8, "Pradera", "Herbívoro (pasto)", "Grande", "Café")
    print("\n--- CABALLO ---")
    print(caballo1.mostrar_informacion_caballo())
    print(caballo1.moverse())
    print(caballo1.comunicarse())
    print(caballo1.reproducirse())
    print(caballo1.alimentarse())
    print(caballo1.adaptacion())
    
   
    hipopotamo1 = Hipopotamo("Moto Moto", 12, "Ríos de África", "Herbívoro (plantas)", 1800, "Territorial")
    print("\n--- HIPOPÓTAMO ---")
    print(hipopotamo1.mostrar_informacion_hipopotamo())
    print(hipopotamo1.moverse())
    print(hipopotamo1.comunicarse())
    print(hipopotamo1.reproducirse())
    print(hipopotamo1.descansar())
    print(hipopotamo1.interaccion_social())
    
  
    ave1 = Ave("Águila Real", 5, "Montañas", "Carnívoro (roedores)", "Marrón con blanco", 220)
    print("\n--- AVE ---")
    print(ave1.mostrar_informacion_ave())
    print(ave1.moverse())
    print(ave1.comunicarse())
    print(ave1.reproducirse())
    print(ave1.anidar())
    
    pato1 = Pato("Donald", 3, "Lagos y lagunas", "Omnívoro", "Verde y café", "Ancho y plano")
    print("\n--- PATO ---")
    print(pato1.mostrar_informacion_pato())
    print(pato1.moverse())
    print(pato1.comunicarse())
    print(pato1.reproducirse())
    print(pato1.nadar())

if __name__ == "__main__":
    main_animales()

